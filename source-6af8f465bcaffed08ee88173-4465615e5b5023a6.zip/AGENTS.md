# AGENTS.md

## O que é

Site demonstrativo (front-end apenas) do programa de fidelidade **Lumina**, ligado ao **Summer Bank**. Estrutura de navegação inspirada nos grandes programas de pontos brasileiros, com a identidade visual própria da Lumina. Textos em português do Brasil.

Regra de negócio central: cartão Summer Bank = **2,2 pts por US$ 1**; outros cartões = **0,8 pt por US$ 1**. Mude só em `src/lib/points.ts`.

## Stack

TanStack Start + React 19, Tailwind CSS 4 (tema em `src/styles.css`), shadcn/ui em `src/components/ui`, lucide-react, sonner para toasts. Deploy na Netlify via `@netlify/vite-plugin-tanstack-start`. Sem backend, sem banco de dados.

## Estrutura

```
src/
  lib/
    fixtures.ts   # TODOS os dados fictícios (cliente, parceiros, produtos, extrato, menus, níveis)
    points.ts     # taxas de pontos, calcPoints, formatadores pt-BR, cdn() para Netlify Image CDN
    cart.ts       # carrinho de trocas em memória (useSyncExternalStore)
  components/lumina/
    logo.tsx            # LuminaStar, LuminaLogo, SummerBankLogo (SVG/CSS, sem imagens)
    summer-card.tsx     # cartão Summer Bank em CSS
    site-header.tsx     # barra superior escura com busca, menus Juntar/Trocar, saldo e carrinho
    menus.tsx           # menus Juntar/Trocar (dropdown no desktop, lista no sheet mobile)
    bottom-nav.tsx      # navegação inferior mobile (Início/Juntar/Trocar/Mais) com sheet
    site-footer.tsx, page-hero.tsx, tiles.tsx, cards.tsx, points-calculator.tsx
  routes/           # index, juntar, trocar, clube, cartao-summer, minha-conta, como-funciona
public/img/         # fotos geradas para a marca (hero, viagens, experiencias, shopping)
```

## Convenções e decisões

- Paleta da marca: creme `#F8F6F1`, bege `#E7DCCB`, champagne `#C9A66B`, marrom `#2E2A26`; Summer Bank usa gradiente laranja→rosa (`.summer-gradient`, `.summer-text`). Classes Tailwind: `bg-creme`, `bg-bege`, `text-champagne`, `text-champagne-deep`, `bg-marrom`, `text-summer-pink`.
- Fontes: Cormorant Garamond (`font-display`) e Jost (corpo), carregadas do Google Fonts em `__root.tsx`.
- Header, footer e navegação inferior são montados em `__root.tsx`; `<main>` tem `pb-20` no mobile por causa da barra inferior.
- Imagens sempre via `cdn(file, width)` (Netlify Image CDN), nunca o PNG original.
- Links tipados: `AppPath` em `fixtures.ts` lista as rotas; adicione a nova rota ali ao criar páginas.
- Para tornar real: trocar `fixtures.ts` por loaders/server functions com Netlify Database e adicionar login (Netlify Identity).

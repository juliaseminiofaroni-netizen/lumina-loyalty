import { createFileRoute, Link } from '@tanstack/react-router'
import { CreditCard, Gift, ShoppingBag } from 'lucide-react'
import { PageHero } from '@/components/lumina/page-hero'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { tiers } from '@/lib/fixtures'
import { fmtRate, POINTS_PER_DOLLAR } from '@/lib/points'

export const Route = createFileRoute('/como-funciona')({
  head: () => ({ meta: [{ title: 'Como funciona · Lumina' }] }),
  component: ComoFunciona,
})

const steps = [
  { icon: CreditCard, title: 'Use seu cartão', text: `Pague com o cartão Summer Bank e ganhe ${fmtRate(POINTS_PER_DOLLAR.summer)} pontos por dólar. Cartões de outros bancos rendem ${fmtRate(POINTS_PER_DOLLAR.other)} ponto por dólar.` },
  { icon: ShoppingBag, title: 'Compre nos parceiros', text: 'Nas lojas parceiras você soma pontos extras aos pontos do cartão.' },
  { icon: Gift, title: 'Troque pelo que quiser', text: 'Produtos, viagens, experiências, gift cards ou desconto na fatura.' },
]

const faq = [
  { q: 'Quanto custa participar da Lumina?', a: 'Nada. O cadastro é gratuito e você começa a juntar pontos na hora.' },
  { q: 'Qual a ligação entre Lumina e Summer Bank?', a: 'A Lumina é o programa de fidelidade do Summer Bank. Por isso o cartão Summer é o que mais pontua: 2,2 pontos por dólar.' },
  { q: 'Posso usar cartões de outros bancos?', a: 'Pode, sim. Compras com cartões de outros bancos cadastrados rendem 0,8 ponto por dólar.' },
  { q: 'Os pontos expiram?', a: 'Os pontos são válidos por 24 meses a partir da data de crédito. Clientes Constelação têm pontos que não expiram.' },
]

function ComoFunciona() {
  return (
    <>
      <PageHero eyebrow="Como funciona" title="Simples como brilhar." image="experiencias.png">
        Três passos para transformar suas compras em algo especial.
      </PageHero>
      <div className="mx-auto max-w-content px-4 sm:px-6">
        <section className="mt-12 grid gap-5 md:grid-cols-3">
          {steps.map((s, i) => (
            <div key={s.title} className="rounded-3xl bg-card p-7 ring-1 ring-border">
              <p className="font-display text-5xl text-champagne">0{i + 1}</p>
              <s.icon className="mt-4 size-7 text-champagne-deep" strokeWidth={1.4} aria-hidden="true" />
              <h2 className="mt-3 text-lg font-medium">{s.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </section>

        <section className="mt-16">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 className="font-display text-4xl">Clube e níveis</h2>
            <Link to="/clube" className="text-sm font-medium text-champagne-deep hover:underline">
              Conhecer os planos do Clube Lumina →
            </Link>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {tiers.map((t) => (
              <div key={t.name} className="rounded-2xl bg-marrom p-6 text-creme">
                <p className="text-xs tracking-brand text-champagne uppercase">{t.min}</p>
                <p className="mt-1 font-display text-3xl">{t.name}</p>
                <p className="mt-2 text-sm text-creme/70">{t.perk}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-16 max-w-reading">
          <h2 className="font-display text-4xl">Dúvidas frequentes</h2>
          <Accordion type="single" collapsible className="mt-4">
            {faq.map((f) => (
              <AccordionItem key={f.q} value={f.q}>
                <AccordionTrigger className="text-base">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <Link to="/cartao-summer" className="gold-bg mt-8 inline-flex rounded-full px-6 py-3 text-sm font-semibold text-marrom">
            Conhecer o cartão Summer
          </Link>
        </section>
      </div>
    </>
  )
}

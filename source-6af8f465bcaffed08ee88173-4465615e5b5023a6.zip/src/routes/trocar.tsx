import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { ShoppingCart, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { PageHero } from '@/components/lumina/page-hero'
import { ProductCard } from '@/components/lumina/cards'
import { member, products, trocarMenu, type Product } from '@/lib/fixtures'
import { cart, useCart } from '@/lib/cart'
import { fmtPoints } from '@/lib/points'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/trocar')({
  head: () => ({ meta: [{ title: 'Trocar pontos · Lumina' }] }),
  component: Trocar,
})

const categories = ['Todos', 'Produtos', 'Viagens', 'Experiências', 'Gift Cards'] as const
const sorts = { relevancia: 'Mais relevantes', menor: 'Menos pontos', maior: 'Mais pontos' }

function Trocar() {
  const [cat, setCat] = useState<(typeof categories)[number]>('Todos')
  const [sort, setSort] = useState<keyof typeof sorts>('relevancia')
  const items = useCart()

  let list: Product[] = cat === 'Todos' ? products : products.filter((p) => p.category === cat)
  if (sort !== 'relevancia') list = [...list].sort((a, b) => (sort === 'menor' ? a.points - b.points : b.points - a.points))

  const total = items.reduce((s, id) => s + (products.find((p) => p.id === id)?.points ?? 0), 0)

  return (
    <>
      <PageHero eyebrow="Trocar" title="Seus pontos viram algo especial" image="viagens.png">
        Produtos, viagens, experiências e gift cards. Você tem {fmtPoints(member.points)} pontos para usar.
      </PageHero>
      <div className="mx-auto max-w-content px-4 sm:px-6">
        <div className="no-scrollbar -mx-4 mt-8 flex gap-3 overflow-x-auto px-4 sm:-mx-6 sm:px-6">
          {trocarMenu.map((m) => (
            <button
              key={m.label}
              type="button"
              onClick={() => {
                const c = categories.find((x) => x === m.label)
                if (c) setCat(c)
                else toast(`${m.label}: disponível em breve na Lumina.`)
              }}
              className="flex shrink-0 items-center gap-2 rounded-2xl bg-card px-4 py-3 text-sm ring-1 ring-border transition-shadow hover:shadow-md"
            >
              <m.icon className="size-5 text-champagne-deep" aria-hidden="true" /> {m.label}
            </button>
          ))}
        </div>

        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_18rem]">
          <section aria-label="Catálogo">
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button
                    key={c}
                    type="button"
                    aria-pressed={cat === c}
                    onClick={() => setCat(c)}
                    className={cn(
                      'rounded-full border px-4 py-1.5 text-sm transition-colors',
                      cat === c ? 'border-marrom bg-marrom text-creme' : 'bg-card hover:bg-muted',
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
              <label className="flex items-center gap-2 text-sm text-muted-foreground">
                Ordenar
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as keyof typeof sorts)}
                  className="rounded-full border bg-card px-3 py-1.5 text-foreground"
                >
                  {Object.entries(sorts).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
              {list.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>

          <aside className="h-fit rounded-3xl bg-card p-6 ring-1 ring-border lg:sticky lg:top-28">
            <h2 className="flex items-center gap-2 font-display text-2xl">
              <ShoppingCart className="size-5" aria-hidden="true" /> Carrinho de trocas
            </h2>
            {items.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">Seu carrinho está vazio. Escolha algo especial.</p>
            ) : (
              <ul className="mt-4 space-y-2 text-sm">
                {items.map((id, idx) => {
                  const p = products.find((x) => x.id === id)
                  return p ? (
                    <li key={`${id}-${idx}`} className="flex justify-between gap-3">
                      <span className="line-clamp-1">{p.name}</span>
                      <span className="shrink-0 font-medium">{fmtPoints(p.points)}</span>
                    </li>
                  ) : null
                })}
              </ul>
            )}
            <div className="mt-5 space-y-1 border-t pt-4 text-sm">
              <p className="flex justify-between">
                <span className="text-muted-foreground">Total</span>
                <strong>{fmtPoints(total)} pts</strong>
              </p>
              <p className="flex justify-between">
                <span className="text-muted-foreground">Seu saldo</span>
                <span>{fmtPoints(member.points)} pts</span>
              </p>
            </div>
            <button
              type="button"
              disabled={items.length === 0}
              onClick={() => {
                if (total > member.points) {
                  toast.error(`Faltam ${fmtPoints(total - member.points)} pontos. Use o cartão Summer para juntar mais rápido!`)
                } else {
                  toast.success('Troca confirmada! Você receberá os detalhes por e-mail.')
                  cart.clear()
                }
              }}
              className="gold-bg mt-5 w-full rounded-full py-3 text-sm font-semibold text-marrom transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              Finalizar troca
            </button>
            {items.length > 0 && (
              <button
                type="button"
                onClick={() => cart.clear()}
                className="mt-2 flex w-full items-center justify-center gap-1 py-2 text-xs text-muted-foreground hover:text-foreground"
              >
                <Trash2 className="size-3.5" aria-hidden="true" /> Esvaziar carrinho
              </button>
            )}
          </aside>
        </div>
      </div>
    </>
  )
}

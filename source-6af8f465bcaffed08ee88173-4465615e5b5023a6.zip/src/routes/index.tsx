import { useEffect, useState } from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { ArrowRight, ChevronLeft, ChevronRight, Gem, Gift, Heart, Sparkles } from 'lucide-react'
import { LuminaStar, SummerBankLogo } from '@/components/lumina/logo'
import { SummerCard } from '@/components/lumina/summer-card'
import { PointsCalculator } from '@/components/lumina/points-calculator'
import { SectionTitle, Tile } from '@/components/lumina/tiles'
import { PartnerCard, ProductCard } from '@/components/lumina/cards'
import { earnWays, member, partners, products, quickAccess } from '@/lib/fixtures'

/** Destaques Lumina primeiro, depois parceiros com pontuação turbinada. */
const homePartners = [
  ...partners.filter((p) => p.featured),
  ...partners.filter((p) => !p.featured && p.previousRate),
].slice(0, 10)
import { cdn, fmtPoints, fmtRate, POINTS_PER_DOLLAR } from '@/lib/points'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/')({
  component: Home,
})

const slides = [
  {
    id: 'lumina',
    eyebrow: 'Programa de fidelidade',
    title: 'Cada compra te aproxima de algo especial.',
    text: 'Junte pontos no dia a dia e troque por produtos, viagens e experiências únicas.',
    cta: 'Cadastre-se grátis',
    to: '/minha-conta' as const,
    image: 'hero.png',
  },
  {
    id: 'summer',
    eyebrow: 'Exclusivo Summer Bank',
    title: `${fmtRate(POINTS_PER_DOLLAR.summer)} pontos a cada dólar gasto.`,
    text: 'O cartão Summer Bank é o cartão oficial da Lumina. Use. Pontue. Repita.',
    cta: 'Conhecer o cartão',
    to: '/cartao-summer' as const,
    image: 'shopping.png',
  },
  {
    id: 'viagens',
    eyebrow: 'Mais que compras, experiências',
    title: 'Troque seus pontos pela próxima viagem.',
    text: 'Passagens, resorts e momentos inesquecíveis com até 15% menos pontos.',
    cta: 'Ver viagens',
    to: '/trocar' as const,
    image: 'viagens.png',
  },
]

function HeroCarousel() {
  const [i, setI] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % slides.length), 6500)
    return () => clearInterval(t)
  }, [i])
  const go = (d: number) => setI((v) => (v + d + slides.length) % slides.length)

  return (
    <section aria-roledescription="carrossel" aria-label="Destaques" className="relative overflow-hidden rounded-3xl bg-bege">
      <div className="relative h-[26rem] sm:h-[24rem] lg:h-[28rem]">
        {slides.map((s, idx) => (
          <div
            key={s.id}
            aria-hidden={idx !== i}
            className={cn(
              'absolute inset-0 transition-opacity duration-700 motion-reduce:transition-none',
              idx === i ? 'opacity-100' : 'pointer-events-none opacity-0',
            )}
          >
            <img
              src={cdn(s.image, 1600)}
              alt=""
              className="absolute inset-0 h-full w-full object-cover object-right"
              loading={idx === 0 ? 'eager' : 'lazy'}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-creme via-creme/85 to-transparent sm:via-creme/70" />
            <div className="relative flex h-full max-w-xl flex-col justify-center p-7 sm:p-12">
              <p className="flex items-center gap-2 text-xs tracking-brand text-champagne-deep uppercase">
                {s.id === 'summer' ? <SummerBankLogo className="text-lg" /> : <LuminaStar className="size-4" />}
                {s.eyebrow}
              </p>
              <h1 className="mt-4 font-display text-4xl leading-[1.05] font-medium text-marrom sm:text-5xl lg:text-6xl">
                {s.title}
              </h1>
              <p className="mt-4 max-w-md text-muted-foreground">{s.text}</p>
              <Link
                to={s.to}
                tabIndex={idx === i ? 0 : -1}
                className={cn(
                  'mt-7 inline-flex w-fit items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold tracking-wide uppercase shadow-sm transition-opacity hover:opacity-90',
                  s.id === 'summer' ? 'summer-gradient text-white' : 'bg-marrom text-creme',
                )}
              >
                {s.cta} <ArrowRight className="size-4" aria-hidden="true" />
              </Link>
            </div>
          </div>
        ))}
      </div>
      <div className="absolute right-5 bottom-5 flex items-center gap-2">
        <button type="button" onClick={() => go(-1)} aria-label="Destaque anterior" className="grid size-9 place-items-center rounded-full bg-white/80 backdrop-blur hover:bg-white">
          <ChevronLeft className="size-4" />
        </button>
        <button type="button" onClick={() => go(1)} aria-label="Próximo destaque" className="grid size-9 place-items-center rounded-full bg-white/80 backdrop-blur hover:bg-white">
          <ChevronRight className="size-4" />
        </button>
      </div>
      <div className="absolute bottom-7 left-7 flex gap-2 sm:left-12">
        {slides.map((s, idx) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setI(idx)}
            aria-label={`Ir para destaque ${idx + 1}`}
            className={cn('h-1.5 rounded-full transition-all', idx === i ? 'w-8 bg-champagne-deep' : 'w-3 bg-marrom/25')}
          />
        ))}
      </div>
    </section>
  )
}

function BalanceStrip() {
  return (
    <Link
      to="/minha-conta"
      className="group mt-5 flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-card px-6 py-5 ring-1 ring-border transition-shadow hover:shadow-md"
    >
      <div>
        <p className="font-display text-2xl">Olá, {member.firstName}</p>
        <p className="text-sm text-muted-foreground">Seja bem-vinda à Lumina · Nível {member.tier}</p>
      </div>
      <div className="flex items-center gap-6">
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Seus pontos</p>
          <p className="font-display text-4xl leading-none">{fmtPoints(member.points)}</p>
        </div>
        <div className="hidden text-right text-xs text-muted-foreground sm:block">
          <p>{fmtPoints(member.expiringPoints)} pts expiram</p>
          <p>em {member.expiringDate}</p>
        </div>
        <ChevronRight className="size-5 text-champagne-deep transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  )
}

function SummerBand() {
  return (
    <section className="relative mt-16 overflow-hidden rounded-3xl bg-marrom text-creme">
      <div className="summer-gradient absolute -top-32 -right-24 size-96 rounded-full opacity-30 blur-3xl" />
      <div className="relative grid items-center gap-10 p-8 sm:p-12 lg:grid-cols-2">
        <div>
          <div className="flex items-center gap-3">
            <span className="text-xs tracking-brand text-champagne uppercase">Lumina</span>
            <span className="text-champagne">×</span>
            <SummerBankLogo light className="text-2xl" />
          </div>
          <h2 className="mt-5 font-display text-4xl leading-tight sm:text-5xl">
            O cartão que mais pontua na Lumina é o <span className="summer-text font-semibold italic">Summer</span>.
          </h2>
          <p className="mt-4 max-w-md text-creme/75">
            A Lumina é o programa de fidelidade do Summer Bank. Pague com o cartão Summer e veja seus pontos crescerem
            quase três vezes mais rápido.
          </p>
          <div className="mt-8 grid max-w-md grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/10 p-5 ring-1 ring-white/15">
              <p className="font-display text-5xl text-white">{fmtRate(POINTS_PER_DOLLAR.summer)}</p>
              <p className="mt-1 text-sm text-creme/80">pontos por US$ 1 no cartão Summer Bank</p>
            </div>
            <div className="rounded-2xl p-5 ring-1 ring-white/15">
              <p className="font-display text-5xl text-creme/60">{fmtRate(POINTS_PER_DOLLAR.other)}</p>
              <p className="mt-1 text-sm text-creme/60">pontos por US$ 1 em cartões de outros bancos</p>
            </div>
          </div>
          <Link
            to="/cartao-summer"
            className="summer-gradient mt-8 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-white shadow-lg transition-opacity hover:opacity-90"
          >
            Peça seu cartão Summer <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </div>
        <div className="relative mx-auto h-72 w-full max-w-md">
          <SummerCard variant="sunset" className="absolute top-0 left-0 w-[80%] -rotate-6" />
          <SummerCard variant="pink" className="absolute right-0 bottom-0 w-[80%] rotate-3" />
        </div>
      </div>
    </section>
  )
}

const values = [
  { icon: Sparkles, label: 'Exclusividade', text: 'Ofertas e níveis pensados para quem é Lumina.' },
  { icon: Gift, label: 'Benefícios', text: 'Pontos que viram produtos, gift cards e descontos.' },
  { icon: Gem, label: 'Experiências', text: 'Jantares, viagens e momentos que ficam na memória.' },
  { icon: Heart, label: 'Você sempre', text: 'Atendimento próximo e vantagens hoje e amanhã.' },
]

function Home() {
  return (
    <div className="mx-auto max-w-content px-4 pt-5 sm:px-6 sm:pt-8">
      <HeroCarousel />
      <BalanceStrip />

      <section className="mt-12">
        <SectionTitle title="Acesso rápido" />
        <div className="grid grid-cols-3 gap-3 sm:gap-5">
          {quickAccess.map((q) => (
            <Tile key={q.label} item={q} />
          ))}
        </div>
      </section>

      <section className="mt-12">
        <SectionTitle title="Junte pontos de várias formas" />
        <div className="grid grid-cols-3 gap-3 sm:gap-5 lg:grid-cols-6">
          {earnWays.map((q) => (
            <Tile key={q.label} item={q} />
          ))}
        </div>
      </section>

      <SummerBand />

      <section className="mt-16">
        <SectionTitle
          eyebrow="Compre e pontue"
          title="Parceiros em destaque"
          action={
            <Link to="/juntar" className="shrink-0 text-sm font-medium text-champagne-deep hover:underline">
              Ver todos
            </Link>
          }
        />
        <div className="no-scrollbar -mx-4 flex gap-4 overflow-x-auto px-4 pt-3 pb-2 sm:-mx-6 sm:px-6">
          {homePartners.map((p) => (
            <PartnerCard key={p.name} partner={p} />
          ))}
        </div>
      </section>

      <section className="mt-16">
        <SectionTitle
          eyebrow="Troque seus pontos"
          title="Ofertas para você"
          action={
            <Link to="/trocar" className="shrink-0 text-sm font-medium text-champagne-deep hover:underline">
              Ver catálogo
            </Link>
          }
        />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {products.slice(0, 4).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="mt-16 grid items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <p className="text-xs tracking-brand text-champagne-deep uppercase">Faça as contas</p>
          <h2 className="mt-2 font-display text-4xl leading-tight sm:text-5xl">
            Seu dia a dia com mais <em className="gold-text">vantagens</em>.
          </h2>
          <p className="mt-4 max-w-md text-muted-foreground">
            Simule seus gastos e compare quanto você acumula com o cartão Summer Bank e com cartões de outros
            bancos.
          </p>
          <div className="relative mt-8 hidden aspect-[16/10] overflow-hidden rounded-3xl lg:block">
            <img src={cdn('experiencias.png', 900)} alt="Jantar a dois à luz de velas" loading="lazy" className="h-full w-full object-cover" />
          </div>
        </div>
        <PointsCalculator />
      </section>

      <section className="paper mt-16 rounded-3xl px-6 py-14 text-center ring-1 ring-border sm:px-12">
        <LuminaStar className="mx-auto size-10" />
        <h2 className="mt-4 font-display text-3xl sm:text-4xl">Mais do que acumular pontos.</h2>
        <p className="mx-auto mt-3 max-w-reading text-muted-foreground">
          A Lumina foi criada para transformar cada compra em algo especial: sentir-se valorizado, viver
          experiências únicas e ter acesso a benefícios exclusivos.
        </p>
        <div className="mt-10 grid grid-cols-2 gap-8 md:grid-cols-4">
          {values.map((v) => (
            <div key={v.label} className="flex flex-col items-center">
              <v.icon className="size-9 text-champagne" strokeWidth={1.2} aria-hidden="true" />
              <p className="mt-3 text-xs tracking-brand uppercase">{v.label}</p>
              <p className="mt-2 text-sm text-muted-foreground">{v.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

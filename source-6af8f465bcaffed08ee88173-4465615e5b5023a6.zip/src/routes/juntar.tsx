import { createFileRoute, Link } from '@tanstack/react-router'
import { Crown, Info, Star } from 'lucide-react'
import { toast } from 'sonner'
import { PageHero } from '@/components/lumina/page-hero'
import { SectionTitle, Tile } from '@/components/lumina/tiles'
import { PartnerCard } from '@/components/lumina/cards'
import { PointsCalculator } from '@/components/lumina/points-calculator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { earnWays, featuredPartners, partnerCategories, partners, type Partner } from '@/lib/fixtures'
import { fmtPoints, fmtRate, POINTS_PER_DOLLAR } from '@/lib/points'

export const Route = createFileRoute('/juntar')({
  head: () => ({ meta: [{ title: 'Juntar pontos · Lumina' }] }),
  component: Juntar,
})

/** Exemplo usado nos cards de destaque: uma compra de US$ 50 com o cartão Summer. */
const EXAMPLE_USD = 50

function FictionNote({ className }: { className?: string }) {
  return (
    <p className={`flex items-start gap-2 rounded-xl bg-bege/60 px-4 py-3 text-xs text-marrom/80 ${className ?? ''}`}>
      <Info className="mt-0.5 size-4 shrink-0 text-champagne-deep" aria-hidden="true" />
      <span>
        A Lumina é um programa de fidelidade <strong>fictício</strong> e todos os pontos, taxas e ofertas desta página são{' '}
        <strong>fictícios</strong>. As marcas aparecem apenas para ilustrar o site demonstrativo, sem parceria real.
      </span>
    </p>
  )
}

function FeaturedCard({ partner }: { partner: Partner }) {
  const total = Math.floor(EXAMPLE_USD * (partner.rate + POINTS_PER_DOLLAR.summer))
  const direct = Math.floor(EXAMPLE_USD * POINTS_PER_DOLLAR.summer)
  return (
    <article className="relative flex flex-col overflow-hidden rounded-3xl bg-marrom p-6 text-creme">
      <span className="gold-bg absolute top-5 right-5 inline-flex items-center gap-1 rounded-full px-3 py-1 text-[0.65rem] font-semibold tracking-wider text-marrom uppercase">
        <Star className="size-3 fill-current" aria-hidden="true" /> Destaque Lumina
      </span>
      <span
        className="grid size-16 place-items-center rounded-full font-display text-xl tracking-widest text-creme ring-2 ring-champagne"
        style={{ backgroundColor: partner.tone }}
      >
        {partner.initials}
      </span>
      <h3 className="mt-4 font-display text-3xl">{partner.name}</h3>
      <p className="text-xs tracking-brand text-champagne uppercase">{partner.category}</p>
      {partner.tagline && <p className="mt-3 text-sm text-creme/70">{partner.tagline}</p>}

      <div className="mt-5 flex items-end gap-3">
        <p className="font-display text-6xl leading-none text-champagne">{fmtRate(partner.rate)}</p>
        <p className="pb-1 text-sm leading-tight text-creme/80">
          pts por US$ 1<br />comprando pela Lumina
        </p>
      </div>
      {partner.previousRate && (
        <p className="mt-1 text-xs text-creme/50 line-through">antes {fmtRate(partner.previousRate)} pts/US$</p>
      )}

      <div className="mt-5 rounded-2xl bg-white/5 p-4 text-sm ring-1 ring-white/10">
        <p className="text-creme/60">Compra de US$ {EXAMPLE_USD} com o cartão Summer:</p>
        <p className="mt-2 flex justify-between">
          <span>Pela Lumina</span>
          <strong className="text-champagne">{fmtPoints(total)} pts</strong>
        </p>
        <p className="flex justify-between text-creme/60">
          <span>Direto na loja</span>
          <span>{fmtPoints(direct)} pts</span>
        </p>
      </div>

      <button
        type="button"
        onClick={() => toast.success(`Oferta ativada! Compre na ${partner.name} pela Lumina e ganhe ${fmtRate(partner.rate)} pts por US$ 1 (pontos fictícios).`)}
        className="gold-bg mt-6 rounded-full px-5 py-3 text-sm font-semibold text-marrom"
      >
        Ativar oferta
      </button>
    </article>
  )
}

function Juntar() {
  return (
    <>
      <PageHero eyebrow="Juntar" title="Junte pontos de várias formas" image="shopping.png">
        No cartão Summer Bank, nos parceiros, viajando ou comprando pontos. Tudo soma na sua conta Lumina.
      </PageHero>
      <div className="mx-auto max-w-content px-4 sm:px-6">
        <section className="mt-12">
          <div className="grid grid-cols-3 gap-3 sm:gap-5 lg:grid-cols-6">
            {earnWays.map((q) => (
              <Tile key={q.label} item={q} />
            ))}
          </div>
        </section>

        <section className="mt-16">
          <SectionTitle eyebrow="Destaques Lumina" title="Quem pontua mais pela Lumina" />
          <p className="-mt-3 mb-6 max-w-reading text-sm text-muted-foreground">
            Nestes parceiros você ganha muito mais pontos quando a compra começa pela Lumina. Os pontos do parceiro são
            somados aos {fmtRate(POINTS_PER_DOLLAR.summer)} pts/US$ do cartão Summer Bank.
          </p>
          <div className="grid gap-5 md:grid-cols-3">
            {featuredPartners.map((p) => (
              <FeaturedCard key={p.name} partner={p} />
            ))}
          </div>
          <Link
            to="/clube"
            className="mt-5 flex flex-wrap items-center gap-2 rounded-2xl border border-champagne/50 bg-card px-5 py-4 text-sm hover:bg-muted"
          >
            <Crown className="size-5 text-champagne-deep" aria-hidden="true" />
            Assinantes do <strong>Clube Lumina</strong> ganham pontos em dobro ou triplo nos Destaques Lumina.
            <span className="font-medium text-champagne-deep">Conhecer os planos →</span>
          </Link>
        </section>

        <section className="mt-16">
          <SectionTitle eyebrow="Marcas parceiras" title="Compre nos parceiros e pontue mais" />
          <p className="-mt-3 mb-6 max-w-reading text-sm text-muted-foreground">
            Os pontos do parceiro são somados aos pontos do seu cartão. Escolha uma categoria e toque em um parceiro para
            ativar a oferta.
          </p>
          <Tabs defaultValue="Todas" className="gap-6">
            <div className="no-scrollbar -mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
              <TabsList className="h-auto w-max gap-2 bg-transparent p-0 sm:w-auto sm:flex-wrap sm:justify-start">
                {partnerCategories.map((c) => (
                  <TabsTrigger
                    key={c.name}
                    value={c.name}
                    className="h-auto flex-none rounded-full border border-border bg-card px-4 py-1.5 font-normal text-marrom hover:bg-muted data-[state=active]:border-marrom data-[state=active]:bg-marrom data-[state=active]:text-creme data-[state=active]:shadow-none"
                  >
                    <c.icon aria-hidden="true" /> {c.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>
            {partnerCategories.map((c) => {
              const list = c.name === 'Todas' ? partners : partners.filter((p) => p.category === c.name)
              return (
                <TabsContent key={c.name} value={c.name}>
                  <div className="grid grid-cols-2 gap-4 pt-2 sm:grid-cols-3 lg:grid-cols-4">
                    {list.map((p) => (
                      <PartnerCard key={p.name} partner={p} className="w-full" />
                    ))}
                  </div>
                </TabsContent>
              )
            })}
          </Tabs>
          <FictionNote className="mt-8" />
        </section>

        <section className="mt-16">
          <PointsCalculator className="mx-auto max-w-3xl" />
        </section>
      </div>
    </>
  )
}

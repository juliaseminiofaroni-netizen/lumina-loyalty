import { useState } from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { CalendarCheck, Check, Crown, Gift, Info, Percent, Star, X } from 'lucide-react'
import { toast } from 'sonner'
import { PageHero } from '@/components/lumina/page-hero'
import { SectionTitle } from '@/components/lumina/tiles'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { CLUB_ANNUAL_DISCOUNT, CLUB_SUMMER_DISCOUNT, clubPlans, featuredPartners, type ClubPlan } from '@/lib/fixtures'
import { fmtBRL, fmtPoints } from '@/lib/points'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/clube')({
  head: () => ({ meta: [{ title: 'Clube Lumina · Lumina' }] }),
  component: Clube,
})

type Billing = 'mensal' | 'anual'

const pct = (n: number) => `${Math.round(n * 100)}%`

function planPrice(plan: ClubPlan, billing: Billing, summer: boolean) {
  let p = plan.price
  if (billing === 'anual') p *= 1 - CLUB_ANNUAL_DISCOUNT
  if (summer) p *= 1 - CLUB_SUMMER_DISCOUNT
  return p
}

const featuredNames = featuredPartners.map((p) => p.name).join(', ').replace(/, ([^,]*)$/, ' e $1')

const howItWorks = [
  { icon: Crown, title: 'Escolha seu plano', text: 'De 500 a 10.000 pontos por mês. Troque de plano quando quiser.' },
  { icon: Gift, title: 'Ganhe o bônus de boas-vindas', text: 'Os pontos de bônus caem na conta junto com a primeira mensalidade.' },
  { icon: CalendarCheck, title: 'Receba pontos todo mês', text: 'Os pontos do plano são creditados sempre na data da assinatura.' },
  { icon: Percent, title: 'Pontue ainda mais', text: 'Assinantes ganham pontos extras em todos os parceiros Lumina.' },
]

const comparison: { label: string; value: (p: ClubPlan) => string | boolean }[] = [
  { label: 'Pontos por mês', value: (p) => fmtPoints(p.monthlyPoints) },
  { label: 'Bônus de boas-vindas', value: (p) => `${fmtPoints(p.welcomeBonus)} pts` },
  { label: 'Pontos extras nos parceiros', value: (p) => `+${p.partnerBonus}%` },
  { label: 'Multiplicador nos Destaques Lumina', value: (p) => (p.featuredMultiplier ? `${p.featuredMultiplier}x` : false) },
  { label: 'Pontos por ano (sem bônus)', value: (p) => fmtPoints(p.monthlyPoints * 12) },
  { label: 'Frete grátis no Shopping Lumina', value: (p) => p.monthlyPoints >= 2500 },
  { label: 'Pontos que não expiram', value: (p) => p.monthlyPoints >= 5000 },
  { label: 'Salas VIP', value: (p) => (p.monthlyPoints >= 10000 ? 'Ilimitadas' : p.monthlyPoints >= 5000 ? '2 por ano' : false) },
  { label: 'Concierge Lumina 24h', value: (p) => p.monthlyPoints >= 10000 },
]

const faq = [
  { q: 'Quando recebo meus pontos?', a: 'Os pontos do plano e o bônus de boas-vindas são creditados em até 48 horas após o pagamento da primeira mensalidade. Depois, todo mês na mesma data.' },
  { q: 'Posso cancelar a qualquer momento?', a: 'Pode. No plano mensal não há fidelidade nem multa. No plano anual, o valor é pago de uma vez com desconto de 15%.' },
  { q: 'Os pontos extras valem para qualquer compra?', a: 'Os pontos extras do Clube valem para compras em parceiros feitas pela Lumina. Nos Destaques Lumina, os planos a partir do Clube 2.500 multiplicam os pontos do parceiro.' },
  { q: 'Tenho vantagem pagando com o cartão Summer Bank?', a: `Sim. A mensalidade paga com o cartão Summer Bank tem ${pct(CLUB_SUMMER_DISCOUNT)} de desconto e ainda rende 2,2 pontos por dólar, como qualquer compra no cartão.` },
  { q: 'Os pontos são de verdade?', a: 'Não. A Lumina é um programa de fidelidade fictício, criado para um site demonstrativo. Planos, valores e pontos são fictícios e nenhuma cobrança é feita.' },
]

function PlanCard({ plan, billing, summer }: { plan: ClubPlan; billing: Billing; summer: boolean }) {
  const price = planPrice(plan, billing, summer)
  const perThousand = (price / plan.monthlyPoints) * 1000
  return (
    <article
      className={cn(
        'relative flex flex-col rounded-3xl p-6 ring-1',
        plan.popular ? 'bg-marrom text-creme ring-champagne' : 'bg-card ring-border',
      )}
    >
      {plan.popular && (
        <span className="gold-bg absolute -top-3 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 rounded-full px-3 py-1 text-[0.65rem] font-semibold tracking-wider whitespace-nowrap text-marrom uppercase">
          <Star className="size-3 fill-current" aria-hidden="true" /> Mais escolhido
        </span>
      )}
      <p className={cn('text-xs tracking-brand uppercase', plan.popular ? 'text-champagne' : 'text-champagne-deep')}>
        {plan.name}
      </p>
      <p className="mt-2 font-display text-5xl leading-none">{fmtPoints(plan.monthlyPoints)}</p>
      <p className={cn('text-sm', plan.popular ? 'text-creme/70' : 'text-muted-foreground')}>pontos por mês</p>

      <div className="mt-5">
        {(billing === 'anual' || summer) && (
          <p className={cn('text-xs line-through', plan.popular ? 'text-creme/50' : 'text-muted-foreground')}>
            {fmtBRL(plan.price)}/mês
          </p>
        )}
        <p className="text-2xl font-semibold">
          {fmtBRL(price)}
          <span className={cn('text-sm font-normal', plan.popular ? 'text-creme/70' : 'text-muted-foreground')}>/mês</span>
        </p>
        <p className={cn('text-xs', plan.popular ? 'text-creme/60' : 'text-muted-foreground')}>
          {billing === 'anual' ? `${fmtBRL(price * 12)} por ano · ` : ''}
          {fmtBRL(perThousand)} a cada mil pontos
        </p>
      </div>

      <div className={cn('mt-5 grid grid-cols-2 gap-2 text-center text-xs', plan.popular ? 'text-creme' : '')}>
        <div className={cn('rounded-xl p-2', plan.popular ? 'bg-white/10' : 'bg-bege/50')}>
          <p className="font-display text-xl">+{fmtPoints(plan.welcomeBonus)}</p>
          <p className="opacity-70">bônus de boas-vindas</p>
        </div>
        <div className={cn('rounded-xl p-2', plan.popular ? 'bg-white/10' : 'bg-bege/50')}>
          <p className="font-display text-xl">+{plan.partnerBonus}%</p>
          <p className="opacity-70">pts nos parceiros</p>
        </div>
      </div>

      <ul className="mt-5 flex-1 space-y-2 text-sm">
        {plan.perks.map((perk) => (
          <li key={perk} className="flex gap-2">
            <Check className={cn('mt-0.5 size-4 shrink-0', plan.popular ? 'text-champagne' : 'text-champagne-deep')} aria-hidden="true" />
            {perk}
          </li>
        ))}
      </ul>

      <button
        type="button"
        onClick={() =>
          toast.success(`Assinatura simulada do ${plan.name}! Nenhuma cobrança foi feita — os pontos são fictícios.`)
        }
        className={cn(
          'mt-6 rounded-full px-5 py-3 text-sm font-semibold',
          plan.popular ? 'gold-bg text-marrom' : 'border border-champagne text-champagne-deep hover:bg-accent',
        )}
      >
        Assinar {plan.name}
      </button>
    </article>
  )
}

function Clube() {
  const [billing, setBilling] = useState<Billing>('mensal')
  const [summer, setSummer] = useState(true)

  return (
    <>
      <PageHero eyebrow="Clube Lumina" title="Pontos todo mês, vantagens o ano inteiro." image="experiencias.png">
        Assine um plano, receba pontos mensais, ganhe bônus de boas-vindas e pontue mais em todos os parceiros.
      </PageHero>
      <div className="mx-auto max-w-content px-4 sm:px-6">
        <p className="mt-8 flex items-start gap-2 rounded-xl bg-bege/60 px-4 py-3 text-xs text-marrom/80">
          <Info className="mt-0.5 size-4 shrink-0 text-champagne-deep" aria-hidden="true" />
          <span>
            Programa <strong>fictício</strong>: planos, mensalidades e pontos desta página são <strong>fictícios</strong> e
            servem apenas para demonstração. Nenhuma cobrança é realizada.
          </span>
        </p>

        <section className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {howItWorks.map((s) => (
            <div key={s.title} className="rounded-2xl bg-card p-5 ring-1 ring-border">
              <s.icon className="size-7 text-champagne-deep" strokeWidth={1.4} aria-hidden="true" />
              <h2 className="mt-3 font-medium">{s.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </section>

        <section className="mt-16">
          <SectionTitle eyebrow="Planos" title="Escolha o seu Clube" />
          <div className="mb-8 flex flex-wrap items-center gap-4">
            <div className="inline-flex rounded-full bg-card p-1 ring-1 ring-border" role="radiogroup" aria-label="Forma de pagamento">
              {(['mensal', 'anual'] as const).map((b) => (
                <button
                  key={b}
                  type="button"
                  role="radio"
                  aria-checked={billing === b}
                  onClick={() => setBilling(b)}
                  className={cn(
                    'rounded-full px-4 py-1.5 text-sm capitalize transition-colors',
                    billing === b ? 'bg-marrom text-creme' : 'hover:bg-muted',
                  )}
                >
                  {b === 'anual' ? `Anual (−${pct(CLUB_ANNUAL_DISCOUNT)})` : 'Mensal'}
                </button>
              ))}
            </div>
            <label className="inline-flex cursor-pointer items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={summer}
                onChange={(e) => setSummer(e.target.checked)}
                className="size-4 accent-[#C9A66B]"
              />
              Pagar com cartão <span className="summer-text font-semibold">Summer Bank</span> (−{pct(CLUB_SUMMER_DISCOUNT)})
            </label>
          </div>
          <div className="grid gap-5 pt-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
            {clubPlans.map((p) => (
              <PlanCard key={p.id} plan={p} billing={billing} summer={summer} />
            ))}
          </div>
        </section>

        <section className="mt-16 rounded-3xl bg-marrom p-8 text-creme sm:p-10">
          <p className="text-xs tracking-brand text-champagne uppercase">Exclusivo para assinantes</p>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl">Destaques Lumina em dobro ou triplo</h2>
          <p className="mt-3 max-w-reading text-sm text-creme/70">
            A partir do Clube 2.500, os pontos do parceiro são multiplicados em {featuredNames}. Exemplo: na Pizzaria
            Donatello, que já rende 10 pts/US$ pela Lumina, quem assina o Clube 10.000 ganha 30 pts/US$ — mais os
            pontos do cartão.
          </p>
          <Link to="/juntar" className="gold-bg mt-6 inline-flex rounded-full px-6 py-3 text-sm font-semibold text-marrom">
            Ver Destaques Lumina
          </Link>
        </section>

        <section className="mt-16">
          <SectionTitle eyebrow="Compare" title="Tudo o que cada Clube oferece" />
          <div className="overflow-x-auto rounded-2xl ring-1 ring-border">
            <table className="w-full min-w-[720px] bg-card text-sm">
              <thead>
                <tr className="border-b bg-bege/50">
                  <th scope="col" className="px-4 py-3 text-left font-medium">Benefício</th>
                  {clubPlans.map((p) => (
                    <th key={p.id} scope="col" className="px-4 py-3 text-center font-medium">{p.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comparison.map((row) => (
                  <tr key={row.label} className="border-b last:border-0">
                    <th scope="row" className="px-4 py-3 text-left font-normal text-muted-foreground">{row.label}</th>
                    {clubPlans.map((p) => {
                      const v = row.value(p)
                      return (
                        <td key={p.id} className="px-4 py-3 text-center">
                          {v === true ? (
                            <Check className="mx-auto size-4 text-champagne-deep" aria-label="Incluso" />
                          ) : v === false ? (
                            <X className="mx-auto size-4 text-muted-foreground/50" aria-label="Não incluso" />
                          ) : (
                            v
                          )}
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mx-auto mt-16 max-w-reading">
          <h2 className="font-display text-4xl">Dúvidas sobre o Clube</h2>
          <Accordion type="single" collapsible className="mt-4">
            {faq.map((f) => (
              <AccordionItem key={f.q} value={f.q}>
                <AccordionTrigger className="text-base">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      </div>
    </>
  )
}

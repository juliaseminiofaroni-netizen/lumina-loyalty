import { createFileRoute, Link } from '@tanstack/react-router'
import { ChevronRight, CreditCard, Gift, Star, Tag } from 'lucide-react'
import { LuminaStar } from '@/components/lumina/logo'
import { SummerCard } from '@/components/lumina/summer-card'
import { member, statement, tiers } from '@/lib/fixtures'
import { fmtPoints } from '@/lib/points'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/minha-conta')({
  head: () => ({ meta: [{ title: 'Minha conta · Lumina' }] }),
  component: MinhaConta,
})

const shortcuts = [
  { label: 'Resgatar benefícios', icon: Gift, to: '/trocar' as const },
  { label: 'Conhecer níveis', icon: Star, to: '/como-funciona' as const },
  { label: 'Ofertas exclusivas', icon: Tag, to: '/juntar' as const },
  { label: 'Meu cartão Summer', icon: CreditCard, to: '/cartao-summer' as const },
]

function MinhaConta() {
  return (
    <div className="mx-auto max-w-content px-4 py-10 sm:px-6">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <section className="paper relative overflow-hidden rounded-3xl p-8 ring-1 ring-border">
          <LuminaStar className="absolute -top-6 -right-6 size-40 opacity-10" />
          <p className="font-display text-4xl">Olá,</p>
          <p className="text-sm text-muted-foreground">{member.fullName} · bem-vinda à Lumina!</p>
          <div className="mt-6 rounded-2xl bg-card/80 p-6 ring-1 ring-border">
            <p className="text-xs text-muted-foreground">Seus pontos</p>
            <h1 className="font-display text-6xl leading-none">{fmtPoints(member.points)}</h1>
            <p className="mt-2 text-xs text-muted-foreground">
              {fmtPoints(member.expiringPoints)} pontos expiram em {member.expiringDate}
            </p>
          </div>
          <div className="mt-6">
            <div className="flex justify-between text-sm">
              <span>
                Nível <strong>{member.tier}</strong>
              </span>
              <span className="text-muted-foreground">Próximo: {member.nextTier}</span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-bege">
              <div className="gold-bg h-full rounded-full" style={{ width: `${member.tierProgress}%` }} />
            </div>
          </div>
          <ul className="mt-6 space-y-2">
            {shortcuts.map((s) => (
              <li key={s.label}>
                <Link
                  to={s.to}
                  className="flex items-center gap-3 rounded-2xl bg-card/80 px-4 py-3.5 text-sm ring-1 ring-border transition-colors hover:bg-card"
                >
                  <s.icon className="size-5 text-champagne-deep" aria-hidden="true" />
                  <span className="flex-1">{s.label}</span>
                  <ChevronRight className="size-4 text-muted-foreground" />
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section className="space-y-8">
          <div className="rounded-3xl bg-card p-6 ring-1 ring-border">
            <h2 className="font-display text-2xl">Cartão vinculado</h2>
            <div className="mt-4 flex flex-wrap items-center gap-6">
              <SummerCard holder={member.fullName.toUpperCase()} className="max-w-[16rem]" />
              <div className="text-sm">
                <p className="font-medium">Summer Bank •••• {member.cardLast4}</p>
                <p className="text-muted-foreground">Acumulando 2,2 pts por US$ 1</p>
              </div>
            </div>
          </div>

          <div className="rounded-3xl bg-card p-6 ring-1 ring-border">
            <h2 className="font-display text-2xl">Extrato</h2>
            <ul className="mt-4 divide-y">
              {statement.map((s) => (
                <li key={s.date + s.description} className="flex items-center justify-between gap-4 py-3.5 text-sm">
                  <div>
                    <p>{s.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {s.date}
                      {s.card === 'summer' && ' · 2,2 pts/US$'}
                      {s.card === 'other' && ' · 0,8 pt/US$'}
                    </p>
                  </div>
                  <span className={cn('shrink-0 font-display text-xl', s.points < 0 ? 'text-muted-foreground' : 'text-champagne-deep')}>
                    {s.points > 0 ? '+' : ''}
                    {fmtPoints(s.points)}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>

      <section className="mt-10 rounded-3xl bg-card p-6 ring-1 ring-border">
        <h2 className="font-display text-2xl">Níveis Lumina</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {tiers.map((t) => (
            <div key={t.name} className={cn('rounded-2xl p-5 ring-1 ring-border', t.name === member.tier && 'bg-accent ring-champagne')}>
              <p className="text-xs tracking-brand text-champagne-deep uppercase">{t.min}</p>
              <p className="mt-1 font-display text-2xl">{t.name}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t.perk}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

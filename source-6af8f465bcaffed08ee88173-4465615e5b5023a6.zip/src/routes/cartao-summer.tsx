import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { BadgePercent, Contact, Globe, ShieldCheck, Smartphone, Star } from 'lucide-react'
import { toast } from 'sonner'
import { SummerBankLogo, LuminaStar } from '@/components/lumina/logo'
import { SummerCard } from '@/components/lumina/summer-card'
import { PointsCalculator } from '@/components/lumina/points-calculator'
import { calcPoints, fmtPoints, fmtRate, fmtUSD, POINTS_PER_DOLLAR } from '@/lib/points'

export const Route = createFileRoute('/cartao-summer')({
  head: () => ({ meta: [{ title: 'Cartão Summer Bank · Lumina' }] }),
  component: CartaoSummer,
})

const perks = [
  { icon: Star, title: `${fmtRate(POINTS_PER_DOLLAR.summer)} pts por dólar`, text: 'Acúmulo turbinado e exclusivo na Lumina.' },
  { icon: Globe, title: 'Compras nacionais e internacionais', text: 'Pontue em qualquer lugar do mundo.' },
  { icon: Contact, title: 'Pagamento por aproximação', text: 'Rápido e prático no contactless.' },
  { icon: ShieldCheck, title: 'Mais segurança', text: 'Proteção em todas as suas compras.' },
  { icon: BadgePercent, title: 'Ofertas e descontos', text: 'Condições especiais nos parceiros Lumina.' },
  { icon: Smartphone, title: 'App completo', text: 'Fatura, cartão virtual e pontos em um só lugar.' },
]

const examples = [50, 250, 1200]

function CartaoSummer() {
  const [sent, setSent] = useState(false)
  return (
    <>
      <section className="relative overflow-hidden bg-[#fff3ec]">
        <div className="summer-gradient absolute -top-40 -right-40 size-[36rem] rounded-full opacity-25 blur-3xl" />
        <div className="relative mx-auto grid max-w-content items-center gap-12 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:py-20">
          <div>
            <div className="flex items-center gap-3">
              <SummerBankLogo className="text-4xl" />
              <span className="text-2xl text-champagne">×</span>
              <span className="flex items-center gap-1.5 font-display text-xl tracking-[0.25em]">
                <LuminaStar className="size-4" /> LUMINA
              </span>
            </div>
            <p className="mt-8 text-xs tracking-brand text-summer-pink uppercase">Mais que um cartão</p>
            <h1 className="mt-2 font-display text-5xl leading-[1.05] font-medium sm:text-6xl">
              <em className="summer-text">é liberdade</em> para você — e pontos na Lumina.
            </h1>
            <p className="mt-5 max-w-md text-muted-foreground">
              O cartão Summer Bank é o cartão oficial do programa Lumina. Cada dólar gasto vira{' '}
              <strong className="text-foreground">{fmtRate(POINTS_PER_DOLLAR.summer)} pontos</strong>, contra{' '}
              {fmtRate(POINTS_PER_DOLLAR.other)} ponto em cartões de outros bancos.
            </p>
            <a
              href="#pedir"
              className="summer-gradient mt-8 inline-flex rounded-full px-7 py-3 text-sm font-semibold tracking-wide text-white uppercase shadow-lg transition-opacity hover:opacity-90"
            >
              Peça já o seu
            </a>
          </div>
          <div className="relative mx-auto h-80 w-full max-w-lg">
            <SummerCard variant="sunset" className="absolute top-4 left-0 w-[78%] -rotate-8" />
            <SummerCard variant="pink" className="absolute right-0 bottom-0 w-[78%] rotate-4" />
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-content px-4 sm:px-6">
        <section className="mt-16 grid grid-cols-2 gap-4 md:grid-cols-3">
          {perks.map((p) => (
            <div key={p.title} className="rounded-2xl bg-card p-6 ring-1 ring-border">
              <span className="grid size-12 place-items-center rounded-full bg-[#fde3ef]">
                <p.icon className="size-5 text-summer-pink" aria-hidden="true" />
              </span>
              <h2 className="mt-4 font-medium">{p.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{p.text}</p>
            </div>
          ))}
        </section>

        <section className="mt-16">
          <h2 className="font-display text-4xl">Compare o acúmulo</h2>
          <div className="mt-6 overflow-x-auto rounded-2xl ring-1 ring-border">
            <table className="w-full min-w-[32rem] bg-card text-left text-sm">
              <thead className="bg-muted text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 font-medium">Valor da compra</th>
                  <th className="px-5 py-3 font-medium">Cartão Summer Bank ({fmtRate(POINTS_PER_DOLLAR.summer)}/US$)</th>
                  <th className="px-5 py-3 font-medium">Outros cartões ({fmtRate(POINTS_PER_DOLLAR.other)}/US$)</th>
                </tr>
              </thead>
              <tbody>
                {examples.map((v) => (
                  <tr key={v} className="border-t">
                    <td className="px-5 py-4">{fmtUSD(v)}</td>
                    <td className="px-5 py-4 font-display text-xl text-summer-pink">{fmtPoints(calcPoints(v, 'summer'))} pts</td>
                    <td className="px-5 py-4 font-display text-xl text-muted-foreground">{fmtPoints(calcPoints(v, 'other'))} pts</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section id="pedir" className="mt-16 grid scroll-mt-28 gap-8 lg:grid-cols-2">
          <PointsCalculator />
          <div className="rounded-3xl bg-marrom p-8 text-creme">
            <SummerBankLogo light className="text-3xl" />
            <h2 className="mt-5 font-display text-3xl">Peça seu cartão Summer</h2>
            <p className="mt-2 text-sm text-creme/70">Ganhe 1.000 pontos Lumina de boas-vindas na primeira compra.</p>
            {sent ? (
              <p className="mt-8 rounded-2xl bg-white/10 p-5 text-sm">
                Recebemos seu pedido! O Summer Bank vai entrar em contato em breve. ☀️
              </p>
            ) : (
              <form
                className="mt-6 space-y-3"
                onSubmit={(e) => {
                  e.preventDefault()
                  setSent(true)
                  toast.success('Pedido enviado ao Summer Bank!')
                }}
              >
                {[
                  { id: 'nome', label: 'Nome completo', type: 'text' },
                  { id: 'email', label: 'E-mail', type: 'email' },
                  { id: 'tel', label: 'Celular', type: 'tel' },
                ].map((f) => (
                  <label key={f.id} className="block text-sm">
                    <span className="text-creme/80">{f.label}</span>
                    <input
                      required
                      type={f.type}
                      name={f.id}
                      className="mt-1 w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-creme outline-none focus:border-champagne"
                    />
                  </label>
                ))}
                <button type="submit" className="summer-gradient mt-3 w-full rounded-full py-3 text-sm font-semibold text-white">
                  Quero meu cartão
                </button>
                <p className="text-xs text-creme/50">Demonstração: nenhum dado é enviado.</p>
              </form>
            )}
          </div>
        </section>
      </div>
    </>
  )
}

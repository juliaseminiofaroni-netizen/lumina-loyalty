/** Regras de acúmulo da Lumina. Um único lugar para mudar as taxas. */
export const POINTS_PER_DOLLAR = {
  summer: 2.2,
  other: 0.8,
} as const

export type CardKind = keyof typeof POINTS_PER_DOLLAR

export function calcPoints(dollars: number, card: CardKind) {
  if (!Number.isFinite(dollars) || dollars <= 0) return 0
  return Math.floor(dollars * POINTS_PER_DOLLAR[card])
}

export const fmtPoints = (n: number) => new Intl.NumberFormat('pt-BR').format(Math.round(n))
export const fmtRate = (n: number) => n.toLocaleString('pt-BR', { minimumFractionDigits: 1 })
export const fmtUSD = (n: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'USD' }).format(n)

/** URL otimizada pelo Netlify Image CDN. */
export const cdn = (file: string, w: number) => `/.netlify/images?url=/img/${file}&w=${w}&fm=webp&q=75`
export const fmtBRL = (n: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(n)

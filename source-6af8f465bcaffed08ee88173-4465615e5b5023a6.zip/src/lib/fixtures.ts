/**
 * Dados fictícios da Lumina. Tudo que é "do servidor" mora aqui, para
 * ser trocado por dados reais depois.
 */
import type { LucideIcon } from 'lucide-react'
import {
  Gift, Plane, ShoppingBag, CreditCard, Sparkles, Gem, Heart, Coins, ArrowLeftRight,
  Ticket, Store, Wallet, Crown, Car, BadgePercent, KeyRound, PiggyBank,
  UtensilsCrossed, Shirt, Smartphone, Gamepad2, ShoppingCart, Sofa, BookOpen, ShoppingBasket, LayoutGrid,
} from 'lucide-react'

export type AppPath = '/' | '/juntar' | '/trocar' | '/cartao-summer' | '/minha-conta' | '/como-funciona' | '/clube'

export const member = {
  firstName: 'Maria',
  fullName: 'Maria Ester Jardim',
  points: 2350,
  expiringPoints: 180,
  expiringDate: '31/12/2026',
  tier: 'Aurora',
  nextTier: 'Esplendor',
  tierProgress: 62,
  cardLast4: '4821',
}

export type QuickLink = { label: string; icon: LucideIcon; to: AppPath }

export const quickAccess: QuickLink[] = [
  { label: 'Código de segurança', icon: KeyRound, to: '/minha-conta' },
  { label: 'Como funciona a Lumina', icon: Sparkles, to: '/como-funciona' },
  { label: 'Aprenda a juntar pontos', icon: PiggyBank, to: '/juntar' },
]

export const earnWays: QuickLink[] = [
  { label: 'Pontue nos parceiros', icon: ShoppingBag, to: '/juntar' },
  { label: 'Pontue com o cartão Summer', icon: CreditCard, to: '/cartao-summer' },
  { label: 'Acumule viajando', icon: Plane, to: '/juntar' },
  { label: 'Compre sem sair da Lumina', icon: Store, to: '/trocar' },
  { label: 'Compre pontos', icon: Coins, to: '/juntar' },
  { label: 'Clube Lumina', icon: Crown, to: '/clube' },
]

export type MenuItem = { label: string; icon: LucideIcon; to: AppPath }

export const juntarMenu: MenuItem[] = [
  { label: 'Clube Lumina', icon: Crown, to: '/clube' },
  { label: 'Shopping Lumina', icon: Store, to: '/trocar' },
  { label: 'Em sites parceiros', icon: ShoppingBag, to: '/juntar' },
  { label: 'Comprar pontos', icon: Coins, to: '/juntar' },
  { label: 'Viagens', icon: Plane, to: '/juntar' },
  { label: 'Turbo Lumina', icon: Sparkles, to: '/juntar' },
  { label: 'Mobilidade', icon: Car, to: '/juntar' },
  { label: 'Cartão Summer Bank', icon: CreditCard, to: '/cartao-summer' },
]

export const trocarMenu: MenuItem[] = [
  { label: 'Produtos', icon: Gift, to: '/trocar' },
  { label: 'Viagens', icon: Plane, to: '/trocar' },
  { label: 'Experiências', icon: Gem, to: '/trocar' },
  { label: 'Transferir pontos', icon: ArrowLeftRight, to: '/trocar' },
  { label: 'Pontos viram fatura', icon: Wallet, to: '/trocar' },
  { label: 'Gift Cards', icon: Ticket, to: '/trocar' },
  { label: 'Doações', icon: Heart, to: '/trocar' },
]

export type PartnerCategory =
  | 'Gastronomia'
  | 'Vestuário'
  | 'Joias e Acessórios'
  | 'Tecnologia'
  | 'Games e Entretenimento'
  | 'Marketplaces'
  | 'Beleza'
  | 'Casa e Decoração'
  | 'Viagens'
  | 'Supermercado'
  | 'Livros e Papelaria'

/** Abas da seção "Marcas parceiras", na ordem em que aparecem. */
export const partnerCategories: { name: PartnerCategory | 'Todas'; icon: LucideIcon }[] = [
  { name: 'Todas', icon: LayoutGrid },
  { name: 'Gastronomia', icon: UtensilsCrossed },
  { name: 'Vestuário', icon: Shirt },
  { name: 'Joias e Acessórios', icon: Gem },
  { name: 'Tecnologia', icon: Smartphone },
  { name: 'Games e Entretenimento', icon: Gamepad2 },
  { name: 'Marketplaces', icon: ShoppingCart },
  { name: 'Beleza', icon: Sparkles },
  { name: 'Casa e Decoração', icon: Sofa },
  { name: 'Viagens', icon: Plane },
  { name: 'Supermercado', icon: ShoppingBasket },
  { name: 'Livros e Papelaria', icon: BookOpen },
]

export type Partner = {
  name: string
  category: PartnerCategory
  /** pontos por US$ 1 gasto no parceiro (além do cartão) */
  rate: number
  previousRate?: number
  initials: string
  tone: string
  /** Parceiro Destaque Lumina: pontua bem mais comprando pela Lumina */
  featured?: boolean
  tagline?: string
}

export const partners: Partner[] = [
  // Destaques Lumina
  { name: 'Pizzaria Donatello', category: 'Gastronomia', rate: 10, previousRate: 4, initials: 'PD', tone: '#9b3b2a', featured: true, tagline: 'Pizzas de fermentação natural, forno a lenha e delivery próprio.' },
  { name: 'Better Açaí', category: 'Gastronomia', rate: 9, previousRate: 3, initials: 'BA', tone: '#5b2a6e', featured: true, tagline: 'Açaí cremoso com toppings à vontade, na loja ou no delivery.' },
  { name: 'Karen Tavares', category: 'Joias e Acessórios', rate: 12, previousRate: 5, initials: 'KT', tone: '#a88448', featured: true, tagline: 'Semijoias e acessórios autorais com acabamento impecável.' },
  // Gastronomia
  { name: '99Food', category: 'Gastronomia', rate: 3, previousRate: 2, initials: '99', tone: '#d9a400' },
  { name: "McDonald's", category: 'Gastronomia', rate: 2.5, initials: 'MC', tone: '#b3261e' },
  { name: 'Outback', category: 'Gastronomia', rate: 4, initials: 'OB', tone: '#6b3a22' },
  { name: 'Starbucks', category: 'Gastronomia', rate: 3, initials: 'SB', tone: '#1e5b3e' },
  // Vestuário
  { name: 'Renner', category: 'Vestuário', rate: 4, previousRate: 2, initials: 'RE', tone: '#b3122e' },
  { name: 'C&A', category: 'Vestuário', rate: 3.5, initials: 'CA', tone: '#1f4e9c' },
  { name: 'Zara', category: 'Vestuário', rate: 3, initials: 'ZA', tone: '#2e2a26' },
  { name: 'Riachuelo', category: 'Vestuário', rate: 3, initials: 'RI', tone: '#4a4a4a' },
  { name: 'Nike', category: 'Vestuário', rate: 5, previousRate: 3, initials: 'NK', tone: '#3b342e' },
  { name: 'Maison Aurèle', category: 'Vestuário', rate: 6, previousRate: 3, initials: 'MA', tone: '#2e2a26' },
  // Joias e Acessórios
  { name: 'Vivara', category: 'Joias e Acessórios', rate: 6, initials: 'VI', tone: '#7a5c3a' },
  { name: 'Pandora', category: 'Joias e Acessórios', rate: 5, previousRate: 3, initials: 'PA', tone: '#c08a9a' },
  { name: 'Chilli Beans', category: 'Joias e Acessórios', rate: 4, initials: 'CB', tone: '#a3221c' },
  { name: 'Swarovski', category: 'Joias e Acessórios', rate: 5, initials: 'SW', tone: '#5a6b78' },
  // Tecnologia
  { name: 'Apple', category: 'Tecnologia', rate: 2, initials: 'AP', tone: '#3b342e' },
  { name: 'Samsung', category: 'Tecnologia', rate: 2.5, previousRate: 1.5, initials: 'SG', tone: '#1c3f8a' },
  { name: 'Dell', category: 'Tecnologia', rate: 3, initials: 'DE', tone: '#24618f' },
  { name: 'Pixel Store', category: 'Tecnologia', rate: 2, initials: 'PS', tone: '#3b342e' },
  // Games e Entretenimento
  { name: 'PlayStation', category: 'Games e Entretenimento', rate: 3, previousRate: 2, initials: 'PS', tone: '#1d3f8f' },
  { name: 'Xbox', category: 'Games e Entretenimento', rate: 3, initials: 'XB', tone: '#2f6b2f' },
  { name: 'Nintendo', category: 'Games e Entretenimento', rate: 2.5, initials: 'NT', tone: '#b3261e' },
  { name: 'Ingresso Prime', category: 'Games e Entretenimento', rate: 4, initials: 'IP', tone: '#6f5428' },
  // Marketplaces
  { name: 'Shopee', category: 'Marketplaces', rate: 2, previousRate: 1, initials: 'SH', tone: '#d4502a' },
  { name: 'Mercado Livre', category: 'Marketplaces', rate: 2.5, initials: 'ML', tone: '#c9a100' },
  { name: 'Amazon', category: 'Marketplaces', rate: 2, initials: 'AM', tone: '#2e2a26' },
  { name: 'Magalu', category: 'Marketplaces', rate: 3, initials: 'MG', tone: '#1a5fb4' },
  { name: 'AliExpress', category: 'Marketplaces', rate: 1.5, initials: 'AE', tone: '#b8331f' },
  // Demais categorias
  { name: 'Essenza Beauty', category: 'Beleza', rate: 8, previousRate: 4, initials: 'EB', tone: '#c9a66b' },
  { name: 'Casa Travertino', category: 'Casa e Decoração', rate: 4, initials: 'CT', tone: '#a88448' },
  { name: 'Voa Brasil Air', category: 'Viagens', rate: 3, previousRate: 2, initials: 'VB', tone: '#6f5428' },
  { name: 'Hotéis Solaris', category: 'Viagens', rate: 5, initials: 'HS', tone: '#8c7b66' },
  { name: 'Mercado Fino', category: 'Supermercado', rate: 1.5, initials: 'MF', tone: '#b08a4f' },
  { name: 'Livraria Página', category: 'Livros e Papelaria', rate: 3, previousRate: 1, initials: 'LP', tone: '#5a4e43' },
]

export const featuredPartners = partners.filter((p) => p.featured)

/** Planos do Clube Lumina (valores fictícios). */
export type ClubPlan = {
  id: string
  name: string
  monthlyPoints: number
  /** mensalidade em R$ */
  price: number
  welcomeBonus: number
  /** % de pontos extras nas compras em parceiros */
  partnerBonus: number
  /** multiplicador extra nos parceiros Destaque Lumina */
  featuredMultiplier?: number
  popular?: boolean
  perks: string[]
}

export const clubPlans: ClubPlan[] = [
  {
    id: 'c500', name: 'Clube 500', monthlyPoints: 500, price: 24.9, welcomeBonus: 500, partnerBonus: 10,
    perks: ['500 pontos todo mês', 'Bônus de boas-vindas de 500 pts', '+10% de pontos nos parceiros', 'Ofertas exclusivas para assinantes', 'Cancele quando quiser'],
  },
  {
    id: 'c1000', name: 'Clube 1.000', monthlyPoints: 1000, price: 44.9, welcomeBonus: 1500, partnerBonus: 15,
    perks: ['1.000 pontos todo mês', 'Bônus de boas-vindas de 1.500 pts', '+15% de pontos nos parceiros', 'Pontos válidos por 36 meses', 'Acesso antecipado às promoções'],
  },
  {
    id: 'c2500', name: 'Clube 2.500', monthlyPoints: 2500, price: 104.9, welcomeBonus: 5000, partnerBonus: 25, featuredMultiplier: 2, popular: true,
    perks: ['2.500 pontos todo mês', 'Bônus de boas-vindas de 5.000 pts', '+25% de pontos nos parceiros', 'Pontos em dobro nos Destaques Lumina', 'Frete grátis no Shopping Lumina', 'Pontos válidos por 48 meses'],
  },
  {
    id: 'c5000', name: 'Clube 5.000', monthlyPoints: 5000, price: 199.9, welcomeBonus: 12000, partnerBonus: 40, featuredMultiplier: 2,
    perks: ['5.000 pontos todo mês', 'Bônus de boas-vindas de 12.000 pts', '+40% de pontos nos parceiros', 'Pontos em dobro nos Destaques Lumina', 'Frete grátis e entrega expressa', 'Pontos que não expiram', '2 acessos a salas VIP por ano'],
  },
  {
    id: 'c10000', name: 'Clube 10.000', monthlyPoints: 10000, price: 379.9, welcomeBonus: 30000, partnerBonus: 60, featuredMultiplier: 3,
    perks: ['10.000 pontos todo mês', 'Bônus de boas-vindas de 30.000 pts', '+60% de pontos nos parceiros', 'Pontos em triplo nos Destaques Lumina', 'Pontos que não expiram', 'Salas VIP ilimitadas', 'Concierge Lumina 24h', 'Upgrade automático para o nível Constelação'],
  },
]

/** Desconto na mensalidade para quem paga com o cartão Summer Bank. */
export const CLUB_SUMMER_DISCOUNT = 0.1
/** Desconto do plano anual (pago de uma vez). */
export const CLUB_ANNUAL_DISCOUNT = 0.15

export type Product = {
  id: string
  name: string
  brand: string
  category: 'Produtos' | 'Viagens' | 'Experiências' | 'Gift Cards'
  points: number
  oldPoints?: number
  icon: LucideIcon
}

export const products: Product[] = [
  { id: 'p1', name: 'Fone de ouvido sem fio Aura', brand: 'Pixel Store', category: 'Produtos', points: 18900, oldPoints: 22400, icon: Sparkles },
  { id: 'p2', name: 'Perfume Lumière 100ml', brand: 'Essenza Beauty', category: 'Produtos', points: 9800, icon: Gem },
  { id: 'p3', name: 'Bolsa de couro Champagne', brand: 'Maison Aurèle', category: 'Produtos', points: 32500, oldPoints: 36000, icon: ShoppingBag },
  { id: 'p4', name: 'Jogo de taças de cristal', brand: 'Casa Travertino', category: 'Produtos', points: 7400, icon: Gift },
  { id: 'v1', name: 'Passagem São Paulo → Lisboa', brand: 'Voa Brasil Air', category: 'Viagens', points: 68000, oldPoints: 79000, icon: Plane },
  { id: 'v2', name: '2 diárias em resort pé na areia', brand: 'Hotéis Solaris', category: 'Viagens', points: 41000, icon: Plane },
  { id: 'e1', name: 'Jantar harmonizado para dois', brand: 'Lumina Experiências', category: 'Experiências', points: 15600, icon: Gem },
  { id: 'e2', name: 'Dia de spa com acompanhante', brand: 'Lumina Experiências', category: 'Experiências', points: 12900, icon: Heart },
  { id: 'g1', name: 'Gift card R$ 100', brand: 'Mercado Fino', category: 'Gift Cards', points: 4200, icon: Ticket },
  { id: 'g2', name: 'Gift card R$ 200', brand: 'Livraria Página', category: 'Gift Cards', points: 8300, icon: Ticket },
  { id: 'p5', name: 'Relógio minimalista Dourado', brand: 'Maison Aurèle', category: 'Produtos', points: 27800, icon: Crown },
  { id: 'e3', name: 'Ingresso camarote premium', brand: 'Lumina Experiências', category: 'Experiências', points: 21000, icon: BadgePercent },
]

export type Statement = { date: string; description: string; points: number; card?: 'summer' | 'other' }

export const statement: Statement[] = [
  { date: '12/11/2026', description: 'Compra no cartão Summer Bank · US$ 120,00', points: 264, card: 'summer' },
  { date: '10/11/2026', description: 'Bônus Maison Aurèle (6 pts/US$)', points: 480 },
  { date: '08/11/2026', description: 'Compra em cartão de outro banco · US$ 75,00', points: 60, card: 'other' },
  { date: '05/11/2026', description: 'Troca: Gift card R$ 100', points: -4200 },
  { date: '01/11/2026', description: 'Compra no cartão Summer Bank · US$ 540,00', points: 1188, card: 'summer' },
  { date: '28/10/2026', description: 'Boas-vindas Lumina + Summer Bank', points: 1000 },
]

export const tiers = [
  { name: 'Aurora', min: '0', perk: 'Acúmulo padrão e ofertas exclusivas' },
  { name: 'Esplendor', min: '15 mil pts/ano', perk: '+10% de pontos e frete grátis no Shopping' },
  { name: 'Constelação', min: '50 mil pts/ano', perk: '+25% de pontos, salas VIP e concierge' },
]

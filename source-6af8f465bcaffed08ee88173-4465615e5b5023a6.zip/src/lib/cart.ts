import { useSyncExternalStore } from 'react'

/** Carrinho de trocas em memória do navegador (demonstração). */
let items: string[] = []
const listeners = new Set<() => void>()
const emit = () => listeners.forEach((l) => l())

export const cart = {
  add(id: string) {
    items = [...items, id]
    emit()
  },
  clear() {
    items = []
    emit()
  },
}

const subscribe = (l: () => void) => {
  listeners.add(l)
  return () => listeners.delete(l)
}
const empty: string[] = []

export function useCart() {
  return useSyncExternalStore(subscribe, () => items, () => empty)
}

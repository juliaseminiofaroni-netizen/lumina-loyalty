import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { ArrowRight, CreditCard } from 'lucide-react'
import { calcPoints, fmtPoints, fmtRate, POINTS_PER_DOLLAR } from '@/lib/points'
import { cn } from '@/lib/utils'
import { LuminaStar } from './logo'

const presets = [100, 500, 1000, 3000]

export function PointsCalculator({ className }: { className?: string }) {
  const [amount, setAmount] = useState(1000)
  const summer = calcPoints(amount, 'summer')
  const other = calcPoints(amount, 'other')
  const extraYear = (summer - other) * 12

  return (
    <div className={cn('rounded-3xl border bg-card p-6 shadow-sm sm:p-8', className)}>
      <p className="text-xs tracking-brand text-champagne-deep uppercase">Simulador de pontos</p>
      <h3 className="mt-2 font-display text-3xl">Quanto você gasta por mês?</h3>

      <label htmlFor="gasto" className="mt-6 block text-sm text-muted-foreground">
        Gasto mensal no cartão (em dólares)
      </label>
      <div className="mt-2 flex items-center gap-2 rounded-2xl border bg-background px-4 py-3 focus-within:ring-2 focus-within:ring-ring">
        <span className="font-medium text-muted-foreground">US$</span>
        <input
          id="gasto"
          type="number"
          inputMode="decimal"
          min={0}
          value={Number.isNaN(amount) ? '' : amount}
          onChange={(e) => setAmount(e.target.valueAsNumber)}
          className="w-full bg-transparent text-2xl font-medium outline-none"
        />
      </div>
      <input
        type="range"
        min={0}
        max={5000}
        step={50}
        value={Number.isNaN(amount) ? 0 : Math.min(amount, 5000)}
        onChange={(e) => setAmount(e.target.valueAsNumber)}
        aria-label="Ajustar gasto mensal"
        className="mt-4 w-full accent-[#a88448]"
      />
      <div className="mt-3 flex flex-wrap gap-2">
        {presets.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => setAmount(p)}
            className={cn(
              'rounded-full border px-3 py-1 text-sm transition-colors',
              amount === p ? 'border-champagne bg-accent font-medium' : 'hover:bg-muted',
            )}
          >
            US$ {fmtPoints(p)}
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <div className="summer-gradient relative overflow-hidden rounded-2xl p-5 text-white">
          <p className="flex items-center gap-2 text-sm font-medium">
            <CreditCard className="size-4" aria-hidden="true" /> Cartão Summer Bank
          </p>
          <p className="mt-3 font-display text-5xl leading-none">{fmtPoints(summer)}</p>
          <p className="mt-1 text-sm opacity-90">pontos/mês · {fmtRate(POINTS_PER_DOLLAR.summer)} pts por US$ 1</p>
          <LuminaStar className="absolute -right-3 -bottom-3 size-20 opacity-30" />
        </div>
        <div className="rounded-2xl border bg-muted p-5">
          <p className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <CreditCard className="size-4" aria-hidden="true" /> Cartões de outros bancos
          </p>
          <p className="mt-3 font-display text-5xl leading-none text-muted-foreground">{fmtPoints(other)}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            pontos/mês · {fmtRate(POINTS_PER_DOLLAR.other)} pts por US$ 1
          </p>
        </div>
      </div>

      <p className="mt-5 text-sm">
        Com o Summer Bank você junta{' '}
        <strong className="text-champagne-deep">{fmtPoints(extraYear)} pontos a mais por ano</strong> —{' '}
        {(POINTS_PER_DOLLAR.summer / POINTS_PER_DOLLAR.other).toLocaleString('pt-BR', { maximumFractionDigits: 2 })}× mais pontos.
      </p>
      <Link
        to="/cartao-summer"
        className="gold-bg mt-5 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-marrom shadow-sm transition-opacity hover:opacity-90"
      >
        Quero o cartão Summer <ArrowRight className="size-4" aria-hidden="true" />
      </Link>
    </div>
  )
}

import { Link } from '@tanstack/react-router'
import { LuminaLogo, SummerBankLogo } from './logo'

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-marrom text-creme/80">
      <div className="mx-auto grid max-w-content gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <LuminaLogo tone="light" showTagline />
          <p className="mt-5 max-w-sm font-display text-xl text-creme italic">
            Cada compra te aproxima de algo especial.
          </p>
          <div className="mt-6 flex items-center gap-3 text-sm">
            <span>Um programa</span>
            <SummerBankLogo light className="text-xl" />
          </div>
        </div>
        <div>
          <p className="mb-3 text-xs tracking-brand text-champagne uppercase">Lumina</p>
          <ul className="space-y-2 text-sm">
            <li><Link to="/juntar" className="hover:text-white">Juntar pontos</Link></li>
            <li><Link to="/trocar" className="hover:text-white">Trocar pontos</Link></li>
            <li><Link to="/clube" className="hover:text-white">Clube Lumina</Link></li>
            <li><Link to="/como-funciona" className="hover:text-white">Como funciona</Link></li>
            <li><Link to="/minha-conta" className="hover:text-white">Minha conta</Link></li>
          </ul>
        </div>
        <div>
          <p className="mb-3 text-xs tracking-brand text-champagne uppercase">Summer Bank</p>
          <ul className="space-y-2 text-sm">
            <li><Link to="/cartao-summer" className="hover:text-white">Cartão Summer</Link></li>
            <li><Link to="/cartao-summer" className="hover:text-white">2,2 pontos por dólar</Link></li>
            <li><Link to="/cartao-summer" className="hover:text-white">Peça o seu cartão</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <p className="mx-auto max-w-content px-4 py-5 text-xs text-creme/50 sm:px-6">
          © 2026 Lumina Programa de Fidelidade · Programa fictício: site demonstrativo, com pontos e dados fictícios.
        </p>
      </div>
    </footer>
  )
}

import { Link } from '@tanstack/react-router'
import type { QuickLink } from '@/lib/fixtures'
import { cn } from '@/lib/utils'

/** Cartão de atalho no estilo "Acesso rápido". */
export function Tile({ item, className }: { item: QuickLink; className?: string }) {
  return (
    <Link
      to={item.to}
      className={cn(
        'group flex flex-col overflow-hidden rounded-2xl bg-card shadow-[0_6px_20px_-10px_rgba(46,42,38,0.25)] ring-1 ring-border transition-all hover:-translate-y-0.5 hover:shadow-[0_14px_28px_-12px_rgba(46,42,38,0.35)] motion-reduce:transition-none',
        className,
      )}
    >
      <div className="paper grid h-24 place-items-center sm:h-28">
        <span className="relative grid size-14 place-items-center rounded-full bg-bege/70">
          <item.icon className="size-7 text-champagne-deep transition-transform group-hover:scale-110" strokeWidth={1.5} aria-hidden="true" />
          <span className="gold-bg absolute -top-0.5 -right-0.5 size-3 rotate-45 rounded-[2px]" />
        </span>
      </div>
      <p className="flex min-h-16 items-center justify-center px-3 py-3 text-center text-sm leading-snug sm:text-[0.95rem]">
        {item.label}
      </p>
    </Link>
  )
}

export function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        {eyebrow && <p className="mb-1 text-xs tracking-brand text-champagne-deep uppercase">{eyebrow}</p>}
        <h2 className="font-display text-3xl font-medium sm:text-4xl">{title}</h2>
      </div>
      {action}
    </div>
  )
}

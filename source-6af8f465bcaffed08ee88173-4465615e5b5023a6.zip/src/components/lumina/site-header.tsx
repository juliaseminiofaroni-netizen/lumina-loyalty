import { useState } from 'react'
import { Link, useNavigate } from '@tanstack/react-router'
import { Search, ShoppingCart, UserRound } from 'lucide-react'
import { toast } from 'sonner'
import { LuminaLogo } from './logo'
import { HeaderMenu } from './menus'
import { useCart } from '@/lib/cart'
import { member } from '@/lib/fixtures'
import { fmtPoints } from '@/lib/points'

export function SiteHeader() {
  const cartItems = useCart()
  const navigate = useNavigate()
  const [q, setQ] = useState('')

  return (
    <header className="sticky top-0 z-40 bg-marrom text-creme shadow-[0_1px_0_rgba(201,166,107,0.25)]">
      <div className="mx-auto flex max-w-content items-center gap-4 px-4 pt-3 pb-3 sm:px-6 md:gap-6">
        <Link to="/" aria-label="Lumina — página inicial" className="shrink-0">
          <LuminaLogo tone="light" />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Principal">
          <HeaderMenu kind="juntar" />
          <HeaderMenu kind="trocar" />
          <Link
            to="/cartao-summer"
            className="rounded-full px-3 py-2 text-sm font-medium text-creme/90 transition-colors hover:bg-white/10 hover:text-white"
          >
            Cartão Summer
          </Link>
          <Link
            to="/como-funciona"
            className="rounded-full px-3 py-2 text-sm font-medium text-creme/90 transition-colors hover:bg-white/10 hover:text-white"
          >
            Como funciona
          </Link>
        </nav>

        <form
          role="search"
          className="ml-auto hidden flex-1 md:block md:max-w-xs xl:max-w-sm"
          onSubmit={(e) => {
            e.preventDefault()
            navigate({ to: '/trocar' })
            if (q) toast(`Mostrando resultados para “${q}”`)
          }}
        >
          <label className="flex items-center gap-2 rounded-full bg-white px-4 py-2 text-marrom">
            <Search className="size-4 text-muted-foreground" aria-hidden="true" />
            <span className="sr-only">Buscar na Lumina</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar na Lumina"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </label>
        </form>

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <Link
            to="/minha-conta"
            className="hidden items-center gap-2 rounded-full border border-champagne/40 px-3 py-1.5 text-sm transition-colors hover:bg-white/10 sm:flex"
          >
            <UserRound className="size-4" aria-hidden="true" />
            <span>
              Olá, {member.firstName} ·{' '}
              <strong className="font-semibold text-champagne">{fmtPoints(member.points)} pts</strong>
            </span>
          </Link>
          <Link
            to="/trocar"
            aria-label={`Carrinho de trocas, ${cartItems.length} itens`}
            className="relative grid size-10 place-items-center rounded-full transition-colors hover:bg-white/10"
          >
            <ShoppingCart className="size-5" aria-hidden="true" />
            {cartItems.length > 0 && (
              <span className="gold-bg absolute -top-0.5 -right-0.5 grid size-5 place-items-center rounded-full text-[0.65rem] font-semibold text-marrom">
                {cartItems.length}
              </span>
            )}
          </Link>
        </div>
      </div>

      {/* busca mobile, como no app */}
      <div className="px-4 pb-3 md:hidden">
        <form
          role="search"
          onSubmit={(e) => {
            e.preventDefault()
            navigate({ to: '/trocar' })
          }}
        >
          <label className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 text-marrom">
            <Search className="size-5 text-muted-foreground" aria-hidden="true" />
            <span className="sr-only">Buscar na Lumina</span>
            <input
              placeholder="Buscar na Lumina"
              className="w-full bg-transparent outline-none placeholder:text-muted-foreground"
            />
          </label>
        </form>
      </div>
      <div className="h-px bg-gradient-to-r from-transparent via-champagne/60 to-transparent" />
    </header>
  )
}

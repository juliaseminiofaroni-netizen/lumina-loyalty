import { cdn } from '@/lib/points'
import { LuminaStar } from './logo'

export function PageHero({
  eyebrow,
  title,
  image,
  children,
}: {
  eyebrow: string
  title: string
  image: string
  children?: React.ReactNode
}) {
  return (
    <section className="relative overflow-hidden bg-bege">
      <img src={cdn(image, 1600)} alt="" className="absolute inset-0 h-full w-full object-cover object-right" />
      <div className="absolute inset-0 bg-gradient-to-r from-creme via-creme/90 to-creme/30" />
      <div className="relative mx-auto max-w-content px-4 py-14 sm:px-6 sm:py-20">
        <p className="flex items-center gap-2 text-xs tracking-brand text-champagne-deep uppercase">
          <LuminaStar className="size-4" /> {eyebrow}
        </p>
        <h1 className="mt-3 max-w-2xl font-display text-4xl leading-tight font-medium sm:text-6xl">{title}</h1>
        {children && <p className="mt-4 max-w-lg text-muted-foreground">{children}</p>}
      </div>
    </section>
  )
}

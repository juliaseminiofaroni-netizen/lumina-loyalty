import { cn } from '@/lib/utils'

export function LuminaStar({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true" className={className}>
      <defs>
        <linearGradient id="lumina-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f1d9a6" />
          <stop offset="45%" stopColor="#c9a66b" />
          <stop offset="100%" stopColor="#8a6a35" />
        </linearGradient>
      </defs>
      <path
        d="M32 0 C33.6 20 40 29.5 64 32 C40 34.5 33.6 44 32 64 C30.4 44 24 34.5 0 32 C24 29.5 30.4 20 32 0 Z"
        fill="url(#lumina-gold)"
      />
    </svg>
  )
}

export function LuminaLogo({
  className,
  tone = 'dark',
  showTagline = false,
}: {
  className?: string
  tone?: 'dark' | 'light'
  showTagline?: boolean
}) {
  return (
    <span className={cn('inline-flex flex-col items-center leading-none', className)}>
      <span className="flex items-center gap-2">
        <LuminaStar className="size-5 -translate-y-1" />
        <span
          className={cn(
            'font-display text-2xl font-medium tracking-[0.28em]',
            tone === 'light' ? 'gold-text' : 'text-marrom',
          )}
        >
          LUMINA
        </span>
      </span>
      {showTagline && (
        <span
          className={cn(
            'mt-1 text-[0.55rem] tracking-brand uppercase',
            tone === 'light' ? 'text-bege/70' : 'text-muted-foreground',
          )}
        >
          Programa de fidelidade
        </span>
      )}
    </span>
  )
}

export function SummerBankLogo({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <span className={cn('inline-flex flex-col items-center leading-[0.85]', className)}>
      <svg viewBox="0 0 40 14" aria-hidden="true" className="h-[0.7em] w-auto">
        <path d="M12 14a8 8 0 0 1 16 0Z" fill={light ? '#ffd23f' : '#f7931e'} />
        {[-60, -35, -12, 12, 35, 60].map((a) => (
          <rect
            key={a}
            x="19.2"
            y="0.5"
            width="1.6"
            height="3.5"
            rx="0.8"
            fill={light ? '#ffd23f' : '#f7931e'}
            transform={`rotate(${a} 20 14)`}
          />
        ))}
      </svg>
      <span
        className={cn(
          'font-display text-[1em] font-semibold italic',
          light ? 'text-white' : 'summer-text',
        )}
      >
        Summer
      </span>
      <span className={cn('font-display text-[0.6em] font-semibold', light ? 'text-white' : 'summer-text')}>
        Bank
      </span>
    </span>
  )
}

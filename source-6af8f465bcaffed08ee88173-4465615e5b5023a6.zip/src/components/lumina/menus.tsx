import { Link } from '@tanstack/react-router'
import { ChevronDown, PiggyBank, ShoppingBasket } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { juntarMenu, trocarMenu, type MenuItem, type AppPath } from '@/lib/fixtures'

export const menus = {
  juntar: { title: 'Juntar', learn: 'Aprender a juntar', learnTo: '/juntar' as AppPath, icon: PiggyBank, items: juntarMenu },
  trocar: { title: 'Trocar', learn: 'Aprender a trocar', learnTo: '/como-funciona' as AppPath, icon: ShoppingBasket, items: trocarMenu },
}

export function MenuList({ items, onPick }: { items: MenuItem[]; onPick?: () => void }) {
  return (
    <ul>
      {items.map((it) => (
        <li key={it.label}>
          <Link
            to={it.to}
            onClick={onPick}
            className="flex items-center gap-4 px-5 py-3.5 text-[0.95rem] font-medium text-marrom transition-colors hover:bg-muted focus-visible:bg-muted focus-visible:outline-none"
          >
            <it.icon className="size-5 text-champagne-deep" aria-hidden="true" />
            {it.label}
          </Link>
        </li>
      ))}
    </ul>
  )
}

export function HeaderMenu({ kind }: { kind: keyof typeof menus }) {
  const m = menus[kind]
  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger className="flex items-center gap-1 rounded-full px-3 py-2 text-sm font-medium text-creme/90 transition-colors hover:bg-white/10 hover:text-white data-[state=open]:bg-white/10">
        {m.title} <ChevronDown className="size-4" aria-hidden="true" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" sideOffset={10} className="w-80 rounded-2xl p-0">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <span className="flex items-center gap-3 font-semibold">
            <m.icon className="size-5" aria-hidden="true" /> {m.title}
          </span>
          <Link to={m.learnTo} className="text-sm text-champagne-deep hover:underline">
            {m.learn}
          </Link>
        </div>
        <div className="py-1">
          {m.items.map((it) => (
            <DropdownMenuItem key={it.label} asChild className="gap-4 rounded-none px-5 py-3 text-[0.95rem]">
              <Link to={it.to}>
                <it.icon className="size-5 text-champagne-deep" aria-hidden="true" />
                {it.label}
              </Link>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

import { Plus, Star } from 'lucide-react'
import { toast } from 'sonner'
import type { Partner, Product } from '@/lib/fixtures'
import { member } from '@/lib/fixtures'
import { cart } from '@/lib/cart'
import { fmtPoints, fmtRate } from '@/lib/points'
import { cn } from '@/lib/utils'

export function PartnerCard({ partner, className }: { partner: Partner; className?: string }) {
  return (
    <button
      type="button"
      onClick={() => toast.success(`Ativado! Compre na ${partner.name} e ganhe ${fmtRate(partner.rate)} pts por US$ 1.`)}
      className={cn(
        'relative flex w-44 shrink-0 flex-col items-center rounded-2xl bg-card p-5 text-center ring-1 ring-border transition-shadow hover:shadow-lg',
        partner.featured && 'ring-2 ring-champagne',
        className,
      )}
    >
      {partner.featured && (
        <span className="gold-bg absolute -top-2.5 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 rounded-full px-2.5 py-0.5 text-[0.6rem] font-semibold tracking-wider whitespace-nowrap text-marrom uppercase">
          <Star className="size-3 fill-current" aria-hidden="true" /> Destaque Lumina
        </span>
      )}
      <span
        className="grid size-16 place-items-center rounded-full font-display text-xl tracking-widest text-creme"
        style={{ backgroundColor: partner.tone }}
      >
        {partner.initials}
      </span>
      <span className="mt-3 text-sm font-medium">{partner.name}</span>
      <span className="text-xs text-muted-foreground">{partner.category}</span>
      {partner.previousRate && (
        <span className="mt-3 text-xs text-muted-foreground line-through">era {fmtRate(partner.previousRate)} pts</span>
      )}
      <span className={cn('text-sm', !partner.previousRate && 'mt-3')}>
        até <strong className="font-display text-2xl text-champagne-deep">{fmtRate(partner.rate)}</strong> pts/US$
      </span>
      <span className="mt-1 text-[0.7rem] text-muted-foreground">+ pontos do cartão</span>
    </button>
  )
}

export function ProductCard({ product }: { product: Product }) {
  const canAfford = member.points >= product.points
  const missing = product.points - member.points
  return (
    <article className="flex flex-col overflow-hidden rounded-2xl bg-card ring-1 ring-border">
      <div className="paper relative grid aspect-[4/3] place-items-center">
        <product.icon className="size-14 text-champagne-deep" strokeWidth={1.1} aria-hidden="true" />
        {product.oldPoints && (
          <span className="absolute top-3 left-3 rounded-full bg-marrom px-2.5 py-1 text-[0.65rem] font-medium tracking-wider text-creme uppercase">
            -{Math.round((1 - product.points / product.oldPoints) * 100)}% pontos
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="text-xs text-muted-foreground">{product.brand}</p>
        <h3 className="mt-1 line-clamp-2 min-h-10 text-sm font-medium">{product.name}</h3>
        <div className="mt-3">
          {product.oldPoints && (
            <p className="text-xs text-muted-foreground line-through">{fmtPoints(product.oldPoints)} pts</p>
          )}
          <p className="font-display text-2xl leading-tight">
            {fmtPoints(product.points)} <span className="text-sm font-sans text-muted-foreground">pts</span>
          </p>
          <p className="text-xs text-muted-foreground">
            {canAfford ? 'Você já pode trocar' : `Faltam ${fmtPoints(missing)} pts`}
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            cart.add(product.id)
            toast.success(`${product.name} foi para o carrinho de trocas.`)
          }}
          className="mt-4 inline-flex items-center justify-center gap-1.5 rounded-full border border-champagne px-4 py-2 text-sm font-medium text-champagne-deep transition-colors hover:bg-accent"
        >
          <Plus className="size-4" aria-hidden="true" /> Trocar
        </button>
      </div>
    </article>
  )
}

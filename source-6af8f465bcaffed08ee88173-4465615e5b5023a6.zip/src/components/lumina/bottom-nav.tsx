import { useState } from 'react'
import { Link, useRouterState } from '@tanstack/react-router'
import { House, PiggyBank, ShoppingBasket, Menu, CreditCard, Sparkles, UserRound } from 'lucide-react'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { cn } from '@/lib/utils'
import { menus, MenuList } from './menus'
import type { MenuItem } from '@/lib/fixtures'

const mais: MenuItem[] = [
  { label: 'Minha conta e extrato', icon: UserRound, to: '/minha-conta' },
  { label: 'Cartão Summer Bank', icon: CreditCard, to: '/cartao-summer' },
  { label: 'Como funciona a Lumina', icon: Sparkles, to: '/como-funciona' },
]

type Panel = 'juntar' | 'trocar' | 'mais' | null

export function BottomNav() {
  const [panel, setPanel] = useState<Panel>(null)
  const path = useRouterState({ select: (s) => s.location.pathname })

  const active = panel ?? (path === '/' ? 'home' : path.startsWith('/juntar') ? 'juntar' : path.startsWith('/trocar') ? 'trocar' : 'mais')

  const tabs = [
    { id: 'home', label: 'Início', icon: House },
    { id: 'juntar', label: 'Juntar', icon: PiggyBank },
    { id: 'trocar', label: 'Trocar', icon: ShoppingBasket },
    { id: 'mais', label: 'Mais', icon: Menu },
  ] as const

  const current = panel && panel !== 'mais' ? menus[panel] : null

  return (
    <>
      <nav
        aria-label="Navegação inferior"
        className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t bg-card/95 backdrop-blur md:hidden"
      >
        {tabs.map((t) => {
          const isActive = active === t.id
          const inner = (
            <>
              <span
                className={cn(
                  'absolute inset-x-4 top-0 h-0.5 rounded-full transition-colors',
                  isActive ? 'gold-bg' : 'bg-transparent',
                )}
              />
              <t.icon className="size-6" aria-hidden="true" />
              <span className="text-xs">{t.label}</span>
            </>
          )
          const cls = cn(
            'relative flex flex-col items-center gap-1 py-2.5 transition-colors',
            isActive ? 'font-semibold text-champagne-deep' : 'text-muted-foreground',
          )
          return t.id === 'home' ? (
            <Link key={t.id} to="/" className={cls} onClick={() => setPanel(null)}>
              {inner}
            </Link>
          ) : (
            <button key={t.id} type="button" className={cls} onClick={() => setPanel(panel === t.id ? null : t.id)}>
              {inner}
            </button>
          )
        })}
      </nav>

      <Sheet open={panel !== null} onOpenChange={(o) => !o && setPanel(null)}>
        <SheetContent side="bottom" className="max-h-[80vh] overflow-y-auto rounded-t-3xl pb-24">
          <SheetHeader className="flex-row items-center justify-between border-b px-5">
            <SheetTitle className="flex items-center gap-3">
              {current ? <current.icon className="size-5" aria-hidden="true" /> : <Menu className="size-5" />}
              {current ? current.title : 'Mais'}
            </SheetTitle>
            <SheetDescription className="sr-only">Atalhos da Lumina</SheetDescription>
            {current && (
              <Link to={current.learnTo} onClick={() => setPanel(null)} className="mr-8 text-sm text-champagne-deep">
                {current.learn}
              </Link>
            )}
          </SheetHeader>
          <MenuList items={current ? current.items : mais} onPick={() => setPanel(null)} />
        </SheetContent>
      </Sheet>
    </>
  )
}

import { Wifi } from 'lucide-react'
import { cn } from '@/lib/utils'
import { SummerBankLogo, LuminaStar } from './logo'

export function SummerCard({
  className,
  variant = 'sunset',
  holder = 'MARIA ESTER JARDIM',
}: {
  className?: string
  variant?: 'sunset' | 'pink'
  holder?: string
}) {
  return (
    <div
      className={cn(
        'relative aspect-[1.586] w-full max-w-sm overflow-hidden rounded-2xl p-5 text-white shadow-[0_25px_50px_-20px_rgba(232,49,138,0.55)]',
        className,
      )}
      style={{
        background:
          variant === 'sunset'
            ? 'linear-gradient(125deg,#ffc04a 0%,#f7931e 35%,#ef4f8f 75%,#e8318a 100%)'
            : 'linear-gradient(125deg,#f7931e 0%,#ef4f8f 45%,#e8318a 70%,#c41f72 100%)',
      }}
    >
      <div className="pointer-events-none absolute -bottom-16 -left-10 h-40 w-[140%] rotate-[-8deg] rounded-[50%] bg-white/15" />
      <div className="pointer-events-none absolute -top-20 -right-16 size-48 rounded-full bg-white/10" />
      <div className="relative flex h-full flex-col justify-between">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <div className="h-7 w-10 rounded-md bg-gradient-to-br from-[#f4e2a8] to-[#c9a66b] shadow-inner" />
            <Wifi className="size-4 rotate-90" aria-hidden="true" />
          </div>
          <SummerBankLogo light className="text-2xl drop-shadow" />
        </div>
        <div className="flex items-end justify-between">
          <div>
            <p className="flex items-center gap-1 text-[0.6rem] tracking-[0.25em] uppercase opacity-90">
              <LuminaStar className="size-3" /> Lumina 2,2 pts/US$
            </p>
            <p className="mt-1 text-xs font-medium tracking-[0.2em]">{holder}</p>
          </div>
          <div className="flex -space-x-2" aria-label="Bandeira do cartão">
            <span className="size-7 rounded-full bg-[#eb001b]/90" />
            <span className="size-7 rounded-full bg-[#f79e1b]/90" />
          </div>
        </div>
      </div>
    </div>
  )
}

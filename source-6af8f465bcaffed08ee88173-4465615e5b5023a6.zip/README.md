# Lumina — Programa de Fidelidade

Site demonstrativo da **Lumina**, o programa de fidelidade do **Summer Bank**. A navegação segue o modelo dos grandes programas de pontos brasileiros (barra superior escura com busca, menus Juntar/Trocar, atalhos em cartões, parceiros com "pts por US$", catálogo de trocas e barra inferior no celular), vestido com a identidade visual da Lumina: creme, bege, champagne e marrom-escuro, tipografia serifada fina e a estrela dourada.

## Regras de pontos

| Cartão | Pontos por US$ 1 |
| --- | --- |
| Summer Bank (cartão oficial) | **2,2** |
| Cartões de outros bancos | **0,8** |

As taxas ficam em `src/lib/points.ts` (`POINTS_PER_DOLLAR`) e alimentam o simulador, as tabelas e os textos.

## Páginas

- `/` — início: carrossel de destaques, saldo, Acesso rápido, Junte pontos de várias formas, faixa Summer Bank, parceiros, ofertas, simulador e conceito da marca
- `/juntar` — formas de acumular, parceiros filtráveis por categoria e simulador
- `/trocar` — catálogo com filtros, ordenação e carrinho de trocas
- `/cartao-summer` — cartão Summer Bank, benefícios, comparativo 2,2 × 0,8 e pedido do cartão
- `/minha-conta` — saldo, nível, cartão vinculado e extrato (cliente fictícia)
- `/como-funciona` — passo a passo, níveis e perguntas frequentes

Todos os dados são fictícios e ficam em `src/lib/fixtures.ts`. Nada é salvo: carrinho e formulários funcionam só na tela.

## Tecnologias

TanStack Start (React 19), Tailwind CSS 4, componentes shadcn/ui, ícones lucide, imagens servidas pelo Netlify Image CDN. Hospedado na Netlify.

## Rodar localmente

```bash
pnpm install
pnpm dev        # http://localhost:3000
# ou, com emulação da Netlify (Image CDN):
netlify dev
```

## Próximos passos possíveis

Login de clientes, saldo e extrato reais em banco de dados, integração das compras do cartão Summer para crédito automático de pontos e checkout real das trocas.
